package com.cg.banking.beans;

import java.io.Serializable;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.MapKey;
import javax.persistence.OneToMany;
@Entity
public class Account implements Serializable {
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private long accountNo;	
	private int pinNumber,pinCounter;
	private String accountType,status;
	private float accountBalance;
	@ManyToOne
	@JoinColumn(name="cus_Id")
	public Customer customer;
	@OneToMany(mappedBy="account")
	@MapKey(name="transactionId")
	private Map<Integer,Transaction>transaction=new HashMap<>();

	
	public Account() {}

	public Account(String accountType, float accountBalance) {
		super();
		this.accountType = accountType;
		this.accountBalance = accountBalance;
	}

	

	public Account(int pinNumber, int pinCounter, String accountType, String status, float accountBalance,
			long accountNo, HashMap<Integer, Transaction> transaction) {
		super();
		this.pinNumber = pinNumber;
		this.pinCounter = pinCounter;
		this.accountType = accountType;
		this.status = status;
		this.accountBalance = accountBalance;
		this.accountNo = accountNo;
		this.transaction = transaction;
	}

	public Customer getCustomer() {
		return customer;
	}

	public void setCustomer(Customer customer) {
		this.customer = customer;
	}

	public void setTransaction(Map<Integer, Transaction> transaction) {
		this.transaction = transaction;
	}

	public int getPinNumber() {
		return pinNumber;
	}
	public void setPinNumber(int pinNumber) {
		this.pinNumber = pinNumber;
	}
	public int getPinCounter() {
		return pinCounter;
	}
	public void setPinCounter(int pinCounter) {
		this.pinCounter = pinCounter;
	}
	public String getAccountType() {
		return accountType;
	}
	public void setAccountType(String accountType) {
		this.accountType = accountType;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public float getAccountBalance() {
		return accountBalance;
	}
	public void setAccountBalance(float accountBalance) {
		this.accountBalance = accountBalance;
	}
	public long getAccountNo() {
		return accountNo;
	}
	public void setAccountNo(long accountNo) {
		this.accountNo = accountNo;
	}
	

	public HashMap<Integer, Transaction> getTransaction() {
		return (HashMap<Integer, Transaction>) transaction;
	}

	public void setTransaction(HashMap<Integer, Transaction> transaction) {
		this.transaction = transaction;
	}

	@Override
	public String toString() {
		return "Account [pinNumber=" + pinNumber + ", pinCounter=" + pinCounter + ", accountType=" + accountType
				+ ", status=" + status + ", accountBalance=" + accountBalance + ", accountNo=" + accountNo
				+ ", transaction=" + transaction + "]";
	
	}
}